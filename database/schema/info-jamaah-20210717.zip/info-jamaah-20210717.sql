-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for info_jamaah
CREATE DATABASE IF NOT EXISTS `info_jamaah` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `info_jamaah`;

-- Dumping structure for table info_jamaah.additional_fields
DROP TABLE IF EXISTS `additional_fields`;
CREATE TABLE IF NOT EXISTS `additional_fields` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `model_id` bigint(20) DEFAULT NULL,
  `model_type` varchar(50) DEFAULT NULL,
  `custom_field_id` bigint(20) DEFAULT NULL,
  `value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.additional_fields: ~44 rows (approximately)
/*!40000 ALTER TABLE `additional_fields` DISABLE KEYS */;
INSERT IGNORE INTO `additional_fields` (`id`, `model_id`, `model_type`, `custom_field_id`, `value`) VALUES
	(1, 1, 'App\\Models\\Asset', 1, 'Ya'),
	(2, 1, 'App\\Models\\Asset', 2, '2018'),
	(3, 1, 'App\\Models\\Asset', 3, 'Pembelian'),
	(4, 2, 'App\\Models\\Asset', 2, '2020'),
	(6, 1, 'App\\Models\\Asset', 14, 'Herman Wahyudi'),
	(7, 1, 'App\\Models\\Asset', 4, 'BE 6837 NL'),
	(8, 1, 'App\\Models\\Asset', 5, '2021-05-27T00:00:00.000+07:00'),
	(9, 2, 'App\\Models\\Asset', 5, '2021-05-31T00:00:00.000+07:00'),
	(10, 2, 'App\\Models\\Asset', 3, 'Hibah'),
	(11, 2, 'App\\Models\\Asset', 1, 'Ya'),
	(12, 4, 'App\\Models\\Asset', 1, 'Ya'),
	(13, 4, 'App\\Models\\Asset', 14, 'Herman Wahyudi'),
	(14, 4, 'App\\Models\\Asset', 2, '2020'),
	(15, 4, 'App\\Models\\Asset', 3, 'Sodaqoh Jamaah'),
	(16, 4, 'App\\Models\\Asset', 5, '2021-05-27T00:00:00.000+07:00'),
	(17, 1, 'App\\Models\\Jamaah', 5, '2021-05-27T00:00:00.000+07:00'),
	(23, 6, 'App\\Models\\Asset', 1, 'Ya'),
	(24, 6, 'App\\Models\\Asset', 14, 'Herman Wahyudi'),
	(25, 6, 'App\\Models\\Asset', 2, '2020'),
	(26, 6, 'App\\Models\\Asset', 3, 'Sodaqoh Jamaah'),
	(27, 6, 'App\\Models\\Asset', 5, '2021-05-27T00:00:00.000+07:00'),
	(33, 8, 'App\\Models\\Asset', 1, 'Ya'),
	(34, 8, 'App\\Models\\Asset', 14, 'Herman Wahyudi'),
	(35, 8, 'App\\Models\\Asset', 2, '2020'),
	(36, 8, 'App\\Models\\Asset', 3, 'Sodaqoh Jamaah'),
	(37, 8, 'App\\Models\\Asset', 5, '2021-05-27T00:00:00.000+07:00'),
	(38, 8, 'App\\Models\\Asset', 4, 'BE 6837 NL'),
	(45, 10, 'App\\Models\\Asset', 1, 'Ya'),
	(46, 10, 'App\\Models\\Asset', 14, 'Herman Wahyudi'),
	(47, 10, 'App\\Models\\Asset', 2, '2020'),
	(48, 10, 'App\\Models\\Asset', 3, 'Sodaqoh Jamaah'),
	(49, 10, 'App\\Models\\Asset', 5, '2021-05-27T00:00:00.000+07:00'),
	(50, 10, 'App\\Models\\Asset', 4, 'BE 6837 NL'),
	(51, 11, 'App\\Models\\Asset', 1, 'Ya'),
	(52, 11, 'App\\Models\\Asset', 14, 'Herman Wahyudi'),
	(53, 11, 'App\\Models\\Asset', 2, '2020'),
	(54, 11, 'App\\Models\\Asset', 3, 'Sodaqoh Jamaah'),
	(55, 11, 'App\\Models\\Asset', 5, '2021-05-27T00:00:00.000+07:00'),
	(56, 11, 'App\\Models\\Asset', 4, 'BE 6837 NL'),
	(57, 13, 'App\\Models\\Asset', 5, '2021-07-23T00:00:00.000+07:00'),
	(58, 14, 'App\\Models\\Asset', 5, '2021-07-19T00:00:00.000+07:00'),
	(59, 13, 'App\\Models\\Asset', 3, 'Hibah'),
	(60, 13, 'App\\Models\\Asset', 2, '2014'),
	(61, 13, 'App\\Models\\Asset', 14, 'Qeiza Alula Mazaya');
/*!40000 ALTER TABLE `additional_fields` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.addresses
DROP TABLE IF EXISTS `addresses`;
CREATE TABLE IF NOT EXISTS `addresses` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `addressable_type` varchar(50) DEFAULT NULL,
  `addressable_id` bigint(20) DEFAULT NULL,
  `street_name` varchar(255) DEFAULT NULL,
  `house_no` varchar(50) DEFAULT NULL,
  `rt` varchar(5) DEFAULT NULL,
  `rw` varchar(5) DEFAULT NULL,
  `kelurahan` varchar(50) DEFAULT NULL,
  `kecamatan` varchar(50) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `post_code` smallint(6) DEFAULT NULL,
  `geo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addressable_type_addressable_id` (`addressable_type`,`addressable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.addresses: ~2 rows (approximately)
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT IGNORE INTO `addresses` (`id`, `addressable_type`, `addressable_id`, `street_name`, `house_no`, `rt`, `rw`, `kelurahan`, `kecamatan`, `city`, `post_code`, `geo`) VALUES
	(1, 'App\\Models\\Residance', 1, 'Jl. Komp Japos', 'Blok M5 No 12', '05', '09', 'Jurangmangu Barat', 'Pondok Aren', 'Tangerang Selatan', 15223, NULL),
	(2, 'App\\Models\\Supplier', 1, 'Jl. Komp Japos', '354', NULL, NULL, 'Jurangmangu Barat', NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.assets
DROP TABLE IF EXISTS `assets`;
CREATE TABLE IF NOT EXISTS `assets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `tag_no` varchar(15) DEFAULT NULL,
  `category_enum` varchar(6) DEFAULT NULL,
  `status_enum` varchar(6) DEFAULT NULL,
  `location_id` bigint(20) DEFAULT NULL,
  `pembina_enum` varchar(6) DEFAULT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.assets: ~13 rows (approximately)
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT IGNORE INTO `assets` (`id`, `title`, `tag_no`, `category_enum`, `status_enum`, `location_id`, `pembina_enum`, `created_by_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'LED Monitor 48 Inch', '12345', 'ELCT', 'GOOD', 1, 'JPS', 1, '2021-02-07 15:00:50', '2021-05-23 18:27:37', NULL),
	(2, 'Printer Epson Ink Tank', '11223', 'ELCT', 'GOOD', 1, 'JPS', 1, '2021-04-18 10:27:50', '2021-04-18 10:27:50', NULL),
	(3, 'Laptop Dell XPS', '41331', 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-05-23 20:12:14', '2021-05-23 20:12:14', NULL),
	(4, 'Speaker Active Neozel', '42312', 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-05-23 20:18:31', '2021-05-23 20:18:31', NULL),
	(5, 'Speaker Active Neozel', '42312', 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-07-06 19:24:01', '2021-07-06 19:51:46', '2021-07-06 19:51:46'),
	(6, 'Speaker Active Neozel', '42312', 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-07-06 19:27:04', '2021-07-06 19:37:38', '2021-07-06 19:37:38'),
	(7, 'Speaker Active Neozel #2', '42312', 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-07-06 19:54:33', '2021-07-06 19:59:55', '2021-07-06 19:59:55'),
	(8, 'Speaker Active Neozel #8', NULL, 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-07-06 20:08:40', '2021-07-06 20:14:44', NULL),
	(9, 'Speaker Active Neozel #8 #9', NULL, 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-07-06 20:19:26', '2021-07-06 20:42:03', '2021-07-06 20:42:03'),
	(10, 'Speaker Active Neozel #9', NULL, 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-07-06 20:42:14', '2021-07-07 16:45:18', NULL),
	(11, 'Speaker Active Neozel #19', NULL, 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-07-07 16:44:39', '2021-07-07 16:45:47', NULL),
	(13, 'Speaker Active Neozel #20', NULL, 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-07-10 09:00:14', '2021-07-10 09:00:31', NULL),
	(14, 'Speaker Active Neozel #21', '312341', 'ELCT', 'GOOD', 1, 'JPS', NULL, '2021-07-16 19:53:53', '2021-07-16 19:54:38', NULL);
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.asset_audits
DROP TABLE IF EXISTS `asset_audits`;
CREATE TABLE IF NOT EXISTS `asset_audits` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `audited_at` timestamp NOT NULL,
  `asset_id` bigint(20) DEFAULT NULL,
  `location_id` bigint(20) DEFAULT NULL,
  `asset_status_enum` varchar(6) DEFAULT NULL,
  `notes` varchar(400) DEFAULT NULL,
  `next_audit_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asset_id` (`asset_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.asset_audits: ~12 rows (approximately)
/*!40000 ALTER TABLE `asset_audits` DISABLE KEYS */;
INSERT IGNORE INTO `asset_audits` (`id`, `audited_at`, `asset_id`, `location_id`, `asset_status_enum`, `notes`, `next_audit_at`, `created_by`, `created_at`, `updated_at`) VALUES
	(1, '2021-02-07 15:31:18', 1, 1, 'BRKN', 'LED Monitor masih dalam kedaan terawat dengan baik.', '2021-09-07 00:00:00', NULL, '2021-02-07 15:31:18', '2021-05-28 19:49:55'),
	(2, '2021-04-27 00:00:00', 2, 1, 'GOOD', 'Print bekerja dengan baik', NULL, NULL, '2021-04-26 07:34:29', '2021-04-26 07:34:44'),
	(6, '2021-04-28 00:00:00', 1, 1, 'GOOD', 'Dalam keadaan OK', NULL, NULL, '2021-04-28 17:01:16', '2021-04-28 17:01:16'),
	(7, '2021-04-28 00:00:00', 1, 1, 'GOOD', 'OK', NULL, NULL, '2021-04-28 17:15:49', '2021-04-28 17:15:49'),
	(8, '2021-07-06 00:00:00', 4, 1, 'GOOD', 'ok', NULL, 1, '2021-07-06 19:20:26', '2021-07-06 19:21:08'),
	(10, '2021-07-05 17:00:00', 6, 1, 'GOOD', 'ok', NULL, 1, '2021-07-06 19:27:04', '2021-07-06 19:27:04'),
	(12, '2021-07-05 17:00:00', 8, 1, 'GOOD', 'ok', NULL, 1, '2021-07-06 20:08:40', '2021-07-06 20:08:40'),
	(13, '2021-07-06 00:00:00', 8, 2, 'LOST', 'Tidak tahu', NULL, 1, '2021-07-06 20:18:04', '2021-07-06 20:18:04'),
	(16, '2021-07-05 10:00:00', 10, 1, 'GOOD', 'ok', NULL, 1, '2021-07-06 20:42:14', '2021-07-06 20:42:14'),
	(17, '2021-07-05 17:00:00', 10, 2, 'LOST', 'Tidak tahu', NULL, 1, '2021-07-06 20:42:14', '2021-07-06 20:42:14'),
	(18, '2021-07-05 03:00:00', 11, 1, 'GOOD', 'ok', NULL, 1, '2021-07-07 16:44:39', '2021-07-07 16:44:39'),
	(19, '2021-07-05 10:00:00', 11, 2, 'LOST', 'Tidak tahu', NULL, 1, '2021-07-07 16:44:39', '2021-07-07 16:44:39');
/*!40000 ALTER TABLE `asset_audits` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.asset_maintenances
DROP TABLE IF EXISTS `asset_maintenances`;
CREATE TABLE IF NOT EXISTS `asset_maintenances` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `asset_id` bigint(20) DEFAULT NULL,
  `type_enum` varchar(6) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `supplier_id` bigint(20) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asset_id` (`asset_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.asset_maintenances: ~14 rows (approximately)
/*!40000 ALTER TABLE `asset_maintenances` DISABLE KEYS */;
INSERT IGNORE INTO `asset_maintenances` (`id`, `asset_id`, `type_enum`, `title`, `start_date`, `end_date`, `notes`, `supplier_id`, `created_by`, `created_at`, `updated_at`) VALUES
	(1, 1, 'RPR', 'Perbaikan LCD TV', '2021-03-25 00:00:00', '2021-03-26 00:00:00', 'Dead pixel 3', 1, 1, '2021-02-13 06:11:21', '2021-05-28 19:50:23'),
	(2, 1, 'MNT', 'Perbaikan Stand', '2021-03-20 00:02:03', '2021-03-23 17:00:00', 'Perbaikan stand patah', 1, 1, '2021-03-21 00:39:06', '2021-04-25 09:30:14'),
	(3, 2, 'RPR', 'Perbaikan Printer', '2021-03-20 00:02:03', '2021-03-21 23:25:25', 'Perbaikan tinta bocor', 2, 1, '2021-04-18 10:28:07', '2021-04-18 10:28:07'),
	(4, 2, 'MNT', 'Pembersihan head catridge', '2021-04-25 17:00:00', '2021-04-27 17:00:00', 'Melalui software bawaan', 2, 1, '2021-04-24 12:53:26', '2021-04-24 12:53:26'),
	(5, 1, 'RPR', 'Pembersihan paper jam', '2021-04-23 00:00:00', '2021-04-25 00:00:00', 'Ada kertas nyangkut', 2, 1, '2021-04-25 10:12:00', '2021-04-25 10:12:00'),
	(6, 2, 'RPR', 'Perbaikan Tinta Bocor', '2021-04-29 00:00:00', '2021-04-30 00:00:00', 'Tinta warna bocor', 1, 1, '2021-04-29 07:52:18', '2021-04-29 07:52:18'),
	(7, 4, 'MNT', 'Perawatan Pertama', '2021-07-06 00:00:00', '2021-07-06 00:00:00', 'Kondisi ok', 1, 1, '2021-07-06 19:20:08', '2021-07-06 19:20:08'),
	(9, 6, 'MNT', 'Perawatan Pertama', '2021-07-05 17:00:00', '2021-07-05 17:00:00', 'Kondisi ok', 1, 1, '2021-07-06 19:27:04', '2021-07-06 19:27:04'),
	(11, 8, 'MNT', 'Perawatan Pertama', '2021-07-05 17:00:00', '2021-07-05 17:00:00', 'Kondisi ok', 1, 1, '2021-07-06 20:08:40', '2021-07-06 20:08:40'),
	(12, 8, 'RPR', 'Cek sound', '2021-07-07 00:00:00', '2021-07-07 00:00:00', 'Kabel digigit tikus', 2, 1, '2021-07-06 20:18:34', '2021-07-06 20:18:34'),
	(15, 10, 'MNT', 'Perawatan Pertama', '2021-07-05 10:00:00', '2021-07-05 10:00:00', 'Kondisi ok', 1, 1, '2021-07-06 20:42:14', '2021-07-06 20:42:14'),
	(16, 10, 'RPR', 'Cek sound', '2021-07-06 17:00:00', '2021-07-06 17:00:00', 'Kabel digigit tikus', 2, 1, '2021-07-06 20:42:14', '2021-07-06 20:42:14'),
	(17, 11, 'MNT', 'Perawatan Pertama', '2021-07-05 03:00:00', '2021-07-05 03:00:00', 'Kondisi ok', 1, 1, '2021-07-07 16:44:39', '2021-07-07 16:44:39'),
	(18, 11, 'RPR', 'Cek sound', '2021-07-06 10:00:00', '2021-07-06 10:00:00', 'Kabel digigit tikus', 2, 1, '2021-07-07 16:44:39', '2021-07-07 16:44:39');
/*!40000 ALTER TABLE `asset_maintenances` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.contacts
DROP TABLE IF EXISTS `contacts`;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contactable_type` varchar(50) DEFAULT NULL,
  `contactable_id` bigint(20) DEFAULT NULL,
  `contact_type` varchar(6) DEFAULT NULL,
  `label` varchar(50) DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contactable_type_contactable_id` (`contactable_type`,`contactable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.contacts: ~3 rows (approximately)
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT IGNORE INTO `contacts` (`id`, `contactable_type`, `contactable_id`, `contact_type`, `label`, `value`) VALUES
	(1, 'App\\Models\\Jamaah', 1, 'email', 'Pribadi', 'herman.whyd@gmail.com'),
	(2, 'App\\Models\\Jamaah', 1, 'phone', 'Pribadi', '0878123123123'),
	(3, 'App\\Models\\Supplier', 1, 'phone', 'Budi P', '0877123123');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.custom_fields
DROP TABLE IF EXISTS `custom_fields`;
CREATE TABLE IF NOT EXISTS `custom_fields` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_enum_id` bigint(20) DEFAULT NULL,
  `position` smallint(6) unsigned DEFAULT NULL,
  `field_name` varchar(50) DEFAULT NULL,
  `field_type` varchar(25) DEFAULT NULL,
  `field_reference` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.custom_fields: ~9 rows (approximately)
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
INSERT IGNORE INTO `custom_fields` (`id`, `group_enum_id`, `position`, `field_name`, `field_type`, `field_reference`) VALUES
	(1, 74, 2, 'Bergaransi', 'dropdown', 'Ya,Tidak'),
	(2, 73, 2, 'Tahun Diperoleh', 'dropdown', '2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025'),
	(3, 73, 1, 'Cara Memperoleh', 'text', NULL),
	(4, 75, 1, 'No STNK', 'text', NULL),
	(5, 74, 1, 'Tgl Garansi Berakhir', 'date', NULL),
	(10, 78, 3, 'Golongan Darah', 'dropdown', 'A,B,AB,O'),
	(11, 78, 1, 'Gelar Depan', 'text', NULL),
	(12, 78, 2, 'Gelar Belakang', 'text', NULL),
	(14, 73, 3, 'PIC Pengguna', 'text', NULL);
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.enumables
DROP TABLE IF EXISTS `enumables`;
CREATE TABLE IF NOT EXISTS `enumables` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enum_id` bigint(20) DEFAULT NULL,
  `model_id` bigint(20) DEFAULT NULL,
  `model_type` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `enumable_id_enumable_type` (`model_id`,`model_type`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.enumables: ~1 rows (approximately)
/*!40000 ALTER TABLE `enumables` DISABLE KEYS */;
INSERT IGNORE INTO `enumables` (`id`, `enum_id`, `model_id`, `model_type`, `created_at`, `updated_at`) VALUES
	(1, 87, 1, 'App\\Models\\Jamaah', '2021-05-30 05:50:28', '2021-05-30 05:50:29');
/*!40000 ALTER TABLE `enumables` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.failed_jobs
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.failed_jobs: ~0 rows (approximately)
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.families
DROP TABLE IF EXISTS `families`;
CREATE TABLE IF NOT EXISTS `families` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `kepala_keluarga_id` bigint(20) DEFAULT NULL,
  `label` varchar(100) DEFAULT NULL,
  `residance_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.families: ~2 rows (approximately)
/*!40000 ALTER TABLE `families` DISABLE KEYS */;
INSERT IGNORE INTO `families` (`id`, `kepala_keluarga_id`, `label`, `residance_id`, `created_at`, `updated_at`) VALUES
	(1, 1, 'Keluarga Bpk. Herman', 1, '2021-01-31 18:47:28', '2021-01-31 18:47:30'),
	(2, 1, 'Keluarga Bpk. Herman Dummy', 1, '2021-01-31 18:47:28', '2021-01-31 18:47:30');
/*!40000 ALTER TABLE `families` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.family_members
DROP TABLE IF EXISTS `family_members`;
CREATE TABLE IF NOT EXISTS `family_members` (
  `family_id` bigint(20) NOT NULL,
  `jamaah_id` bigint(20) NOT NULL,
  `relationship_enum` varchar(6) NOT NULL,
  `status` varchar(1) NOT NULL,
  `position` tinyint(2) NOT NULL,
  PRIMARY KEY (`family_id`,`jamaah_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.family_members: ~5 rows (approximately)
/*!40000 ALTER TABLE `family_members` DISABLE KEYS */;
INSERT IGNORE INTO `family_members` (`family_id`, `jamaah_id`, `relationship_enum`, `status`, `position`) VALUES
	(1, 1, 'AYH', 'A', 1),
	(1, 2, 'ANK', 'A', 2),
	(1, 3, 'IBU', 'A', 1),
	(1, 4, 'ANK', 'A', 1),
	(2, 1, 'AYH', 'A', 1);
/*!40000 ALTER TABLE `family_members` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.jamaahs
DROP TABLE IF EXISTS `jamaahs`;
CREATE TABLE IF NOT EXISTS `jamaahs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(150) DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `birth_date` timestamp NULL DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `pembina_enum` varchar(6) DEFAULT NULL,
  `lv_pembinaan_enum` varchar(6) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.jamaahs: ~4 rows (approximately)
/*!40000 ALTER TABLE `jamaahs` DISABLE KEYS */;
INSERT IGNORE INTO `jamaahs` (`id`, `full_name`, `nickname`, `birth_date`, `gender`, `pembina_enum`, `lv_pembinaan_enum`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Herman Wahyudi', 'Herman', '1990-02-06 00:00:00', 'M', 'VJ', 'UBPK', '2021-01-17 06:47:21', '2021-01-17 06:47:22', NULL),
	(2, 'Hiro KZ', 'Hiro', '2020-12-05 00:00:00', 'M', 'VJ', 'PAUD', '2021-01-17 14:41:04', '2021-01-17 14:41:04', NULL),
	(3, 'Pratiwi Anggreini', 'Anggi', '1992-12-10 00:00:00', 'F', 'VJ', 'UIBU', '2021-01-19 19:07:13', '2021-01-19 19:07:13', NULL),
	(4, 'Qeiza Alula Mazaya', 'Qeza', '2017-09-04 00:00:00', 'F', 'VJ', 'CBR', '2021-01-19 19:07:34', '2021-01-19 19:07:35', NULL);
/*!40000 ALTER TABLE `jamaahs` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.jamaah_details
DROP TABLE IF EXISTS `jamaah_details`;
CREATE TABLE IF NOT EXISTS `jamaah_details` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `jamaah_id` bigint(20) DEFAULT NULL,
  `type_enum` varchar(6) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jamaah_id` (`jamaah_id`),
  KEY `detail_type_enum` (`type_enum`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.jamaah_details: ~3 rows (approximately)
/*!40000 ALTER TABLE `jamaah_details` DISABLE KEYS */;
INSERT IGNORE INTO `jamaah_details` (`id`, `jamaah_id`, `type_enum`, `value`) VALUES
	(1, 1, 'GOLDAR', 'B'),
	(2, 1, 'PFNAME', 'Prof'),
	(3, 1, 'SFNAME', 'S.Kom');
/*!40000 ALTER TABLE `jamaah_details` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.jamaah_pembinaans
DROP TABLE IF EXISTS `jamaah_pembinaans`;
CREATE TABLE IF NOT EXISTS `jamaah_pembinaans` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `jamaah_id` bigint(20) NOT NULL,
  `pembina_enum` varchar(6) NOT NULL,
  `lv_pembinaan_enum` varchar(6) NOT NULL,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jamaah_id_pembina_enum_lv_pembinaan_enum` (`jamaah_id`,`pembina_enum`,`lv_pembinaan_enum`),
  KEY `jamaah_id` (`jamaah_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.jamaah_pembinaans: ~2 rows (approximately)
/*!40000 ALTER TABLE `jamaah_pembinaans` DISABLE KEYS */;
INSERT IGNORE INTO `jamaah_pembinaans` (`id`, `jamaah_id`, `pembina_enum`, `lv_pembinaan_enum`, `start_date`, `end_date`) VALUES
	(1, 1, 'VJ', 'RPRP', '2014-01-01 00:00:00', '2016-04-21 00:00:00'),
	(2, 1, 'VJ', 'UBPK', '2021-02-02 07:36:02', NULL);
/*!40000 ALTER TABLE `jamaah_pembinaans` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.locations
DROP TABLE IF EXISTS `locations`;
CREATE TABLE IF NOT EXISTS `locations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type_enum` varchar(6) DEFAULT NULL,
  `label` varchar(100) DEFAULT NULL,
  `pebina_enum` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.locations: ~3 rows (approximately)
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT IGNORE INTO `locations` (`id`, `type_enum`, `label`, `pebina_enum`) VALUES
	(1, 'BGNN', 'Manba\'ul \'Ulum', 'VJ'),
	(2, 'BGNN', 'Gria Aslamba', 'JPS'),
	(3, 'BGNN', 'Gria Astaga', 'JPS');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.media
DROP TABLE IF EXISTS `media`;
CREATE TABLE IF NOT EXISTS `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `generated_conversions` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.media: ~6 rows (approximately)
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT IGNORE INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `generated_conversions`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES
	(1, 'App\\Models\\Asset', 8, 'b202d191-b9ca-44eb-8a14-e66df0e2bf34', 'PHOTO', 'Dragonball-Goku.Png', '8_PHOTO_60e56e0fc9610.Png', 'image/png', 's3', 's3', 18437, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 1, '2021-07-07 16:04:15', '2021-07-07 16:04:18'),
	(2, 'App\\Models\\Asset', 10, 'feb1efd7-86d8-4066-8fee-4fcf2ea307df', 'PHOTO', 'Hyouka.Png', '10_PHOTO_60e577645e3b2.Png', 'image/png', 's3', 's3', 35176, '[]', '{"notes": "Mata ungu"}', '{"THUMB": true}', '[]', 2, '2021-07-07 16:44:04', '2021-07-07 16:44:20'),
	(3, 'App\\Models\\Asset', 11, '274687d7-2d5a-47a6-8b26-d1b3e247da9d', 'PHOTO', 'Hyouka.Png', '10_PHOTO_60e577645e3b2.Png', 'image/png', 's3', 's3', 35176, '[]', '{"notes": "Mata ungu"}', '{"THUMB": true}', '[]', 2, '2021-07-07 16:44:40', '2021-07-07 16:44:41'),
	(4, 'App\\Models\\Asset', 11, '1cb1f868-f8fa-4b10-a551-712b4ff419b0', 'PHOTO', 'IMG_20200207_221156_005.jpg', '11_PHOTO_60e59f671e86f.jpg', 'image/jpeg', 's3', 's3', 1160100, '[]', '{"notes": "Anak Qeiza"}', '{"THUMB": true}', '[]', 3, '2021-07-07 19:34:47', '2021-07-09 14:30:03'),
	(5, 'App\\Models\\Asset', 13, '68235c45-e6d3-4bfe-bac0-af3e63024b5d', 'PHOTO', 'IMG_20200104_112508_280.jpg', '13_PHOTO_60f1800a90060.jpg', 'image/jpeg', 's3', 's3', 1356954, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 4, '2021-07-16 19:48:10', '2021-07-16 19:48:30'),
	(6, 'App\\Models\\Asset', 14, '851bcfea-2761-41a8-9ba3-ad3c24b0d02b', 'PHOTO', 'IMG_20200104_112508_280.jpg', '13_PHOTO_60f1800a90060.jpg', 'image/jpeg', 's3', 's3', 1356954, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 4, '2021-07-16 19:53:57', '2021-07-16 19:54:05');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.migrations
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.migrations: ~7 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT IGNORE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2020_12_16_121441_create_users', 1),
	(3, '2020_12_16_121441_create_media_table', 2),
	(4, '2016_06_27_000000_create_mediable_tables', 3),
	(5, '2020_10_12_000000_add_variants_to_media', 3),
	(6, '2014_10_12_100000_create_password_resets_table', 4),
	(7, '2019_08_19_000000_create_failed_jobs_table', 4),
	(8, '2021_02_15_123105_create_media_table', 4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.m_enums
DROP TABLE IF EXISTS `m_enums`;
CREATE TABLE IF NOT EXISTS `m_enums` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(20) NOT NULL,
  `code` varchar(6) DEFAULT NULL,
  `position` mediumint(8) unsigned DEFAULT NULL,
  `label` varchar(400) DEFAULT NULL,
  `removable` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `grup` (`group`,`code`) USING BTREE,
  KEY `posisi` (`position`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.m_enums: ~64 rows (approximately)
/*!40000 ALTER TABLE `m_enums` DISABLE KEYS */;
INSERT IGNORE INTO `m_enums` (`id`, `group`, `code`, `position`, `label`, `removable`) VALUES
	(13, 'IPORTAL_INFO', 'TAGL', 1, 'Hi, informasi apa yang Anda butuhkan?', 0),
	(14, 'IPORTAL_INFO', 'DESC', 2, 'Porta Informasi (IPortal) Jamaah dibangun untuk memudahkan integrasi sistem Jamaah dengan pengurus terkait. Memudahkan proses monitoring keluar-masuk jamaah tiap kelompok, pengolahan bank data, dan lain sebagainya.', 0),
	(15, 'IPORTAL_INFO', 'TELD', 3, 'Telpon Admin untuk support permasalahan yg terjadi di IPortal', 0),
	(16, 'IPORTAL_INFO', 'TELV', 4, '62-8788-4030-354', 0),
	(17, 'IPORTAL_INFO', 'EMLD', 5, 'Email Admin untuk medapatkan informasi lebih lengkap mengenai IPortal', 0),
	(18, 'IPORTAL_INFO', 'IMLV', 6, 'herman.whyd@gmail.com', 0),
	(22, 'RESIDANCE_TYPE', 'SELF', 1, 'Milik Pribadi (Permanent)', 1),
	(23, 'RESIDANCE_TYPE', 'RENT', 2, 'Kontrak/Sewa (Temporal)', 1),
	(25, 'RESIDANCE_TYPE', 'INHR', 3, 'Ikut Orang Tua', 1),
	(26, 'JAMAAH_DETAIL', 'BLDG', 1, 'Golongan Darah', 1),
	(27, 'ASSET_CATEGORY', 'ELCT', 1, 'Barang Elektronik', 1),
	(29, 'ASSET_CATEGORY', 'LAND', 2, 'Tanah', 1),
	(30, 'ASSET_CATEGORY', 'BULD', 3, 'Gedung/Bangunan', 1),
	(31, 'ASSET_CATEGORY', 'FURN', 4, 'Furnitur', 1),
	(33, 'ASSET_CATEGORY', 'KITB', 5, 'Kitab-kitab', 1),
	(34, 'ASSET_STATUS', 'GOOD', 1, 'Baik', 1),
	(35, 'ASSET_STATUS', 'BRKN', 2, 'Rusak', 1),
	(36, 'ASSET_STATUS', 'LOST', 3, 'Hilang', 1),
	(37, 'ASSET_STATUS', 'ARCV', 4, 'Diarsipkan', 1),
	(38, 'FAMS_RELATIONSHIP', 'AYH', 1, 'Ayah', 1),
	(39, 'FAMS_RELATIONSHIP', 'IBU', 2, 'Ibu', 1),
	(41, 'FAMS_RELATIONSHIP', 'ANK', 3, 'Anak', 1),
	(42, 'JAMAAH_DETAIL', 'GOLDAR', 2, 'Golongan Darah', 1),
	(43, 'LV_PEMBINA', 'DS', 1, 'Desa', 1),
	(44, 'LV_PEMBINA', 'KLP', 2, 'Kelompok', 1),
	(45, 'LV_PEMBINAAN', 'UMUM', 1, 'Umum', 1),
	(47, 'LV_PEMBINAAN', 'UBPK', 2, 'Bapak-Bapak', 1),
	(48, 'LV_PEMBINAAN', 'UIBU', 3, 'Ibu-Ibu', 1),
	(49, 'LV_PEMBINAAN', 'RPRP', 4, 'Remaja PRP', 1),
	(50, 'LV_PEMBINAAN', 'RSBY', 5, 'Remaja Sebaya', 1),
	(51, 'LV_PEMBINAAN', 'CBR', 6, 'Caberawit', 1),
	(52, 'LV_PEMBINAAN', 'PAUD', 7, 'Paud', 1),
	(53, 'PEMBINA_DS', 'JPS', 1, 'Japos', 1),
	(54, 'PEMBINA_JPS', 'VJ', 1, 'Villa Japos', 1),
	(55, 'PEMBINA_JPS', 'TMI', 2, 'Taman Mangu Indah', 1),
	(56, 'PEMBINA_JPS', 'PJI', 3, 'Pondok Jati Indah', 1),
	(57, 'PEMBINA_JPS', 'PDA', 4, 'Pondok Aren', 1),
	(58, 'JAMAAH_DETAIL', 'PFNAME', 3, 'Gelar Depan', 1),
	(60, 'JAMAAH_DETAIL', 'SFNAME', 4, 'Gelar Belakang', 1),
	(61, 'LOCATION_TYPE', 'AREA', 1, 'Area', 1),
	(62, 'LOCATION_TYPE', 'BGNN', 2, 'Bangunan', 1),
	(63, 'LOCATION_TYPE', 'RNGA', 3, 'Ruangan', 1),
	(64, 'ASSET_DETAIL', 'ACQY', 1, 'Tahun Diperoleh', 1),
	(65, 'ASSET_DETAIL', 'ACQM', 2, 'Cara Memperoleh', 1),
	(66, 'MAINTENANCE_TYPE', 'RPR', 1, 'Perbaikan', 1),
	(67, 'MAINTENANCE_TYPE', 'MNT', 2, 'Perawatan Rutin', 1),
	(68, 'ASSET_MEDIA_COLL', 'INVC', 1, 'Faktur Pembelian', 1),
	(69, 'ASSET_MEDIA_COLL', 'DOCS', 2, 'Dokumen Pendukung', 1),
	(70, 'ASSET_MEDIA_COLL', 'PHOTO', 3, 'Foto Aset', 1),
	(71, 'ASSET_MEDIA_COLL', 'AUDIT', 4, 'Dokumentasi Audit', 1),
	(72, 'MAINTENANCE_TYPE', 'DST', 3, 'Pemusnahan', 1),
	(73, 'CUSTOM_FIELD_ASSET', 'MISC', 1, 'Informasi Umum', 1),
	(74, 'CUSTOM_FIELD_ASSET', 'WRNT', 3, 'Informasi Garansi', 1),
	(75, 'CUSTOM_FIELD_ASSET', 'LICE', 2, 'Informasi Dokumen Pendukung', 1),
	(78, 'CUSTOM_FIELD_JAMAAH', 'MISC', 1, 'Informasi Umum', 1),
	(79, 'PENGURUS', 'KIDA', 1, 'KI Daerah', 1),
	(80, 'PENGURUS', 'KUDA', 2, 'KU Daerah', 1),
	(81, 'PENGURUS', 'PNDA', 3, 'PNB Daerah', 1),
	(82, 'PENGURUS', 'KIDES', 4, 'KI Desa', 1),
	(83, 'PENGURUS', 'KUDES', 5, 'KU Desa', 1),
	(84, 'PENGURUS', 'PNDES', 6, 'PNB Desa', 1),
	(85, 'PENGURUS', 'KIKEL', 7, 'KI Kelompok', 1),
	(86, 'PENGURUS', 'KUKEL', 8, 'KU Kelompok', 1),
	(87, 'PENGURUS', 'PNKEL', 9, 'PNB Kelompok', 1);
/*!40000 ALTER TABLE `m_enums` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.notifiers
DROP TABLE IF EXISTS `notifiers`;
CREATE TABLE IF NOT EXISTS `notifiers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) DEFAULT NULL,
  `model_id` bigint(20) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `referable_type` varchar(50) DEFAULT NULL,
  `referable_id` bigint(20) DEFAULT NULL,
  `due_date_at` timestamp NULL DEFAULT NULL,
  `is_repetition` tinyint(4) DEFAULT '1',
  `reminder_days` varchar(50) DEFAULT NULL,
  `last_fired_at` timestamp NULL DEFAULT NULL,
  `last_fired_status` varchar(15) DEFAULT NULL,
  `last_fired_error` mediumtext,
  PRIMARY KEY (`id`),
  KEY `model_type_model_id` (`model_type`,`model_id`),
  KEY `referable_type_referable_id` (`referable_type`,`referable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.notifiers: ~9 rows (approximately)
/*!40000 ALTER TABLE `notifiers` DISABLE KEYS */;
INSERT IGNORE INTO `notifiers` (`id`, `model_type`, `model_id`, `name`, `description`, `referable_type`, `referable_id`, `due_date_at`, `is_repetition`, `reminder_days`, `last_fired_at`, `last_fired_status`, `last_fired_error`) VALUES
	(1, 'App\\Models\\Asset', 1, 'Reminder H-n Sebelum Expire', 'Mengirim notifikasi email', 'App\\Models\\AdditionalField', 8, '2021-05-27 00:00:00', 1, 'H-30;H-60;H-90;H-120', '2021-05-30 00:19:06', 'Success', 'Email was sent to all subscriber'),
	(11, 'App\\Models\\Asset', 3, 'Reminder Next Service', NULL, NULL, NULL, '2021-06-16 00:00:00', 0, 'H-15', NULL, NULL, NULL),
	(12, 'App\\Models\\Asset', 3, 'Reminder Garansi Berakhir', NULL, NULL, NULL, '2021-06-16 00:00:00', 1, 'H-30', NULL, NULL, NULL),
	(15, 'App\\Models\\Asset', 4, 'Reminder Garansi Berakhir', NULL, 'App\\Models\\AdditionalField', 16, '2021-05-27 00:00:00', 1, 'H-30;H-60', NULL, NULL, NULL),
	(17, 'App\\Models\\Asset', 1, 'Reminder Garansis', NULL, 'App\\Models\\AdditionalField', 8, '2021-05-27 00:00:00', 1, 'H-30', NULL, NULL, NULL),
	(18, 'App\\Models\\Asset', 2, 'Reminder Expired', NULL, 'App\\Models\\AdditionalField', 9, '2021-05-31 00:00:00', 1, 'H-30', NULL, NULL, NULL),
	(19, 'App\\Models\\Asset', 11, 'Pengingat 1', NULL, 'App\\Models\\AdditionalField', 55, '2021-05-27 00:00:00', 1, 'H-30', NULL, NULL, NULL),
	(20, 'App\\Models\\Asset', 13, 'Pengingat 1', 'Pengingat Satu', 'App\\Models\\AdditionalField', 57, '2021-07-23 00:00:00', 1, 'H-30;H-60', NULL, NULL, NULL),
	(21, 'App\\Models\\Asset', 14, 'Pengingat 1', 'Pengingat Satu', 'App\\Models\\AdditionalField', 57, '2021-07-16 00:00:00', 1, 'H-30;H-60', NULL, NULL, NULL);
/*!40000 ALTER TABLE `notifiers` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.password_resets
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.rbac_model_has_permissions
DROP TABLE IF EXISTS `rbac_model_has_permissions`;
CREATE TABLE IF NOT EXISTS `rbac_model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `rbac_model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `rbac_permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.rbac_model_has_permissions: ~0 rows (approximately)
/*!40000 ALTER TABLE `rbac_model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbac_model_has_permissions` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.rbac_model_has_roles
DROP TABLE IF EXISTS `rbac_model_has_roles`;
CREATE TABLE IF NOT EXISTS `rbac_model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `rbac_model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `rbac_roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.rbac_model_has_roles: ~2 rows (approximately)
/*!40000 ALTER TABLE `rbac_model_has_roles` DISABLE KEYS */;
INSERT IGNORE INTO `rbac_model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
	(1, 'App\\Models\\User', 1),
	(1, 'App\\Models\\User', 2);
/*!40000 ALTER TABLE `rbac_model_has_roles` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.rbac_permissions
DROP TABLE IF EXISTS `rbac_permissions`;
CREATE TABLE IF NOT EXISTS `rbac_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.rbac_permissions: ~0 rows (approximately)
/*!40000 ALTER TABLE `rbac_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbac_permissions` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.rbac_roles
DROP TABLE IF EXISTS `rbac_roles`;
CREATE TABLE IF NOT EXISTS `rbac_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.rbac_roles: ~1 rows (approximately)
/*!40000 ALTER TABLE `rbac_roles` DISABLE KEYS */;
INSERT IGNORE INTO `rbac_roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
	(1, 'ADMIN', 'api', '2020-12-09 23:54:59', '2020-12-09 23:54:59');
/*!40000 ALTER TABLE `rbac_roles` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.rbac_role_has_permissions
DROP TABLE IF EXISTS `rbac_role_has_permissions`;
CREATE TABLE IF NOT EXISTS `rbac_role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `rbac_role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `rbac_role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `rbac_permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rbac_role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `rbac_roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.rbac_role_has_permissions: ~0 rows (approximately)
/*!40000 ALTER TABLE `rbac_role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbac_role_has_permissions` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.residances
DROP TABLE IF EXISTS `residances`;
CREATE TABLE IF NOT EXISTS `residances` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `label` varchar(50) NOT NULL,
  `type_enum` varchar(6) NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.residances: ~1 rows (approximately)
/*!40000 ALTER TABLE `residances` DISABLE KEYS */;
INSERT IGNORE INTO `residances` (`id`, `label`, `type_enum`, `created_at`, `updated_at`) VALUES
	(1, 'Alamat Domisili', 'RENT', '2021-01-19 19:08:32', '2021-01-19 19:08:33');
/*!40000 ALTER TABLE `residances` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.subscriptions
DROP TABLE IF EXISTS `subscriptions`;
CREATE TABLE IF NOT EXISTS `subscriptions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `subscribe_id` bigint(20) DEFAULT NULL,
  `subscribe_type` varchar(50) DEFAULT NULL,
  `subscriber_id` bigint(20) DEFAULT NULL,
  `subscriber_type` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscribe_id_subscribe_type` (`subscribe_id`,`subscribe_type`),
  KEY `subscriber_id_subscriber_type` (`subscriber_id`,`subscriber_type`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.subscriptions: ~20 rows (approximately)
/*!40000 ALTER TABLE `subscriptions` DISABLE KEYS */;
INSERT IGNORE INTO `subscriptions` (`id`, `subscribe_id`, `subscribe_type`, `subscriber_id`, `subscriber_type`, `created_at`, `updated_at`) VALUES
	(34, 1, 'App\\Models\\Notifier', 82, 'App\\Models\\Enum', '2021-06-16 16:48:01', '2021-06-16 16:48:01'),
	(40, 11, 'App\\Models\\Notifier', 83, 'App\\Models\\Enum', '2021-06-16 17:14:56', '2021-06-16 17:14:56'),
	(47, 12, 'App\\Models\\Notifier', 81, 'App\\Models\\Enum', '2021-06-16 17:28:53', '2021-06-16 17:28:53'),
	(48, 12, 'App\\Models\\Notifier', 87, 'App\\Models\\Enum', '2021-06-16 17:28:54', '2021-06-16 17:28:54'),
	(49, 12, 'App\\Models\\Notifier', 82, 'App\\Models\\Enum', '2021-06-16 17:28:55', '2021-06-16 17:28:55'),
	(50, 11, 'App\\Models\\Notifier', 80, 'App\\Models\\Enum', '2021-06-16 19:21:54', '2021-06-16 19:21:54'),
	(61, 15, 'App\\Models\\Notifier', 79, 'App\\Models\\Enum', '2021-06-18 21:44:39', '2021-06-18 21:44:39'),
	(65, 17, 'App\\Models\\Notifier', 85, 'App\\Models\\Enum', '2021-06-19 06:11:55', '2021-06-19 06:11:55'),
	(66, 17, 'App\\Models\\Notifier', 80, 'App\\Models\\Enum', '2021-06-19 06:25:30', '2021-06-19 06:25:30'),
	(68, 1, 'App\\Models\\Notifier', 79, 'App\\Models\\Enum', '2021-06-19 11:34:40', '2021-06-19 11:34:40'),
	(69, 18, 'App\\Models\\Notifier', 79, 'App\\Models\\Enum', '2021-06-19 11:39:46', '2021-06-19 11:39:46'),
	(70, 18, 'App\\Models\\Notifier', 85, 'App\\Models\\Enum', '2021-06-19 11:39:47', '2021-06-19 11:39:47'),
	(71, 1, 'App\\Models\\Notifier', 85, 'App\\Models\\Enum', '2021-06-26 14:50:59', '2021-06-26 14:50:59'),
	(72, 11, 'App\\Models\\Notifier', 85, 'App\\Models\\Enum', '2021-07-03 19:30:52', '2021-07-03 19:30:52'),
	(73, 19, 'App\\Models\\Notifier', 79, 'App\\Models\\Enum', '2021-07-10 08:52:51', '2021-07-10 08:52:51'),
	(74, 19, 'App\\Models\\Notifier', 85, 'App\\Models\\Enum', '2021-07-10 08:52:51', '2021-07-10 08:52:51'),
	(75, 19, 'App\\Models\\Notifier', 83, 'App\\Models\\Enum', '2021-07-10 08:52:52', '2021-07-10 08:52:52'),
	(76, 20, 'App\\Models\\Notifier', 79, 'App\\Models\\Enum', '2021-07-16 19:53:32', '2021-07-16 19:53:32'),
	(77, 20, 'App\\Models\\Notifier', 85, 'App\\Models\\Enum', '2021-07-16 19:53:33', '2021-07-16 19:53:33'),
	(78, 20, 'App\\Models\\Notifier', 80, 'App\\Models\\Enum', '2021-07-16 19:53:39', '2021-07-16 19:53:39');
/*!40000 ALTER TABLE `subscriptions` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.suppliers
DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.suppliers: ~2 rows (approximately)
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT IGNORE INTO `suppliers` (`id`, `title`) VALUES
	(1, 'Aslamba Qania'),
	(2, 'ISS');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `jamaah_id` bigint(20) NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `mobile` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.users: ~2 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`id`, `jamaah_id`, `email`, `mobile`, `password`, `created_at`, `updated_at`) VALUES
	(1, 1, 'herman.whyd@gmail.com', '087884939354', '$2y$10$LigHc96M88Nvvrd1p3yAFusl3jZb7yU6kdJtCxhc6DgaPyZNLkww6', '2020-12-09 19:10:01', '2020-12-09 19:10:01'),
	(2, 2, 'hirokz@gmail.com', '087812341354', '$2y$10$DbhO08sVLSDTieIFNKrgNe8ODkjlpVi5ALxCaqQPqKLTTbqAB0MWG', '2021-01-17 22:05:56', '2021-01-17 22:05:56');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.variables
DROP TABLE IF EXISTS `variables`;
CREATE TABLE IF NOT EXISTS `variables` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group` varchar(15) DEFAULT NULL,
  `variable_type` varchar(50) DEFAULT NULL,
  `variable_id` bigint(20) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `variable_type_variable_id` (`variable_type`,`variable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.variables: ~0 rows (approximately)
/*!40000 ALTER TABLE `variables` DISABLE KEYS */;
/*!40000 ALTER TABLE `variables` ENABLE KEYS */;

-- Dumping structure for trigger info_jamaah.auto_pos_custf
DROP TRIGGER IF EXISTS `auto_pos_custf`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `auto_pos_custf` BEFORE INSERT ON `custom_fields` FOR EACH ROW BEGIN
	SET NEW.position = (select COALESCE(max(s.position), 0) + 1 from custom_fields s WHERE s.group_enum_id = NEW.group_enum_id);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Dumping structure for trigger info_jamaah.auto_pos_enum
DROP TRIGGER IF EXISTS `auto_pos_enum`;
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
DELIMITER //
CREATE TRIGGER `info_jamaah`.`auto_pos_enum` BEFORE INSERT ON `m_enums` FOR EACH ROW BEGIN
	SET NEW.position = (select COALESCE(max(s.position), 0) + 1 from m_enums s where s.group = NEW.group);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
