-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for info_jamaah
CREATE DATABASE IF NOT EXISTS `info_jamaah` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `info_jamaah`;

-- Dumping structure for table info_jamaah.additional_fields
CREATE TABLE IF NOT EXISTS `additional_fields` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `model_id` bigint(20) DEFAULT NULL,
  `model_type` varchar(50) DEFAULT NULL,
  `custom_field_id` bigint(20) DEFAULT NULL,
  `value` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.additional_fields: ~7 rows (approximately)
/*!40000 ALTER TABLE `additional_fields` DISABLE KEYS */;
INSERT IGNORE INTO `additional_fields` (`id`, `model_id`, `model_type`, `custom_field_id`, `value`) VALUES
	(1, 1, 'App\\Models\\Asset', 1, 'Ya'),
	(2, 1, 'App\\Models\\Asset', 2, '2019'),
	(3, 1, 'App\\Models\\Asset', 3, 'Pembelian'),
	(4, 2, 'App\\Models\\Asset', 2, '2020'),
	(5, 1, 'App\\Models\\Asset', 5, '2021-05-24T00:00:00.000+07:00'),
	(6, 1, 'App\\Models\\Asset', 14, 'Herman Wahyudi'),
	(7, 1, 'App\\Models\\Asset', 4, 'BE 6837 NL');
/*!40000 ALTER TABLE `additional_fields` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.addresses
CREATE TABLE IF NOT EXISTS `addresses` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `addressable_type` varchar(50) DEFAULT NULL,
  `addressable_id` bigint(20) DEFAULT NULL,
  `street_name` varchar(255) DEFAULT NULL,
  `house_no` varchar(50) DEFAULT NULL,
  `rt` varchar(5) DEFAULT NULL,
  `rw` varchar(5) DEFAULT NULL,
  `kelurahan` varchar(50) DEFAULT NULL,
  `kecamatan` varchar(50) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `post_code` smallint(6) DEFAULT NULL,
  `geo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addressable_type_addressable_id` (`addressable_type`,`addressable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.addresses: ~1 rows (approximately)
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
INSERT IGNORE INTO `addresses` (`id`, `addressable_type`, `addressable_id`, `street_name`, `house_no`, `rt`, `rw`, `kelurahan`, `kecamatan`, `city`, `post_code`, `geo`) VALUES
	(1, 'App\\Models\\Residance', 1, 'Jl. Komp Japos', 'Blok M5 No 12', '05', '09', 'Jurangmangu Barat', 'Pondok Aren', 'Tangerang Selatan', 15223, NULL),
	(2, 'App\\Models\\Supplier', 1, 'Jl. Komp Japos', '354', NULL, NULL, 'Jurangmangu Barat', NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.assets
CREATE TABLE IF NOT EXISTS `assets` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `tag_no` varchar(15) DEFAULT NULL,
  `category_enum` varchar(6) DEFAULT NULL,
  `status_enum` varchar(6) DEFAULT NULL,
  `location_id` bigint(20) DEFAULT NULL,
  `owner_enum` varchar(6) DEFAULT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.assets: ~0 rows (approximately)
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT IGNORE INTO `assets` (`id`, `title`, `tag_no`, `category_enum`, `status_enum`, `location_id`, `owner_enum`, `created_by_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'LED Monitor 48 Inch', '12345', 'ELCT', 'GOOD', 1, 'JPS', 1, '2021-02-07 15:00:50', '2021-02-07 15:00:52', NULL),
	(2, 'Printer Epson Ink Tank', '11223', 'ELCT', 'GOOD', 1, 'JPS', 1, '2021-04-18 10:27:50', '2021-04-18 10:27:50', NULL);
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.asset_audits
CREATE TABLE IF NOT EXISTS `asset_audits` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `audited_at` timestamp NOT NULL,
  `asset_id` bigint(20) DEFAULT NULL,
  `location_id` bigint(20) DEFAULT NULL,
  `asset_status_enum` varchar(6) DEFAULT NULL,
  `notes` varchar(400) DEFAULT NULL,
  `next_audit_at` timestamp NULL DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asset_id` (`asset_id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.asset_audits: ~4 rows (approximately)
/*!40000 ALTER TABLE `asset_audits` DISABLE KEYS */;
INSERT IGNORE INTO `asset_audits` (`id`, `audited_at`, `asset_id`, `location_id`, `asset_status_enum`, `notes`, `next_audit_at`, `created_by`, `created_at`, `updated_at`) VALUES
	(1, '2021-02-07 15:31:18', 1, 1, 'GOOD', 'LED Monitor masih dalam kedaan terawat dengan baik.', '2021-09-07 00:00:00', NULL, '2021-02-07 15:31:18', '2021-05-01 07:12:12'),
	(2, '2021-04-27 00:00:00', 2, 1, 'GOOD', 'Print bekerja dengan baik', NULL, NULL, '2021-04-26 07:34:29', '2021-04-26 07:34:44'),
	(6, '2021-04-28 00:00:00', 1, 1, 'GOOD', 'Dalam keadaan OK', NULL, NULL, '2021-04-28 17:01:16', '2021-04-28 17:01:16'),
	(7, '2021-04-28 00:00:00', 1, 1, 'GOOD', 'OK', NULL, NULL, '2021-04-28 17:15:49', '2021-04-28 17:15:49');
/*!40000 ALTER TABLE `asset_audits` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.asset_maintenances
CREATE TABLE IF NOT EXISTS `asset_maintenances` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `asset_id` bigint(20) DEFAULT NULL,
  `type_enum` varchar(6) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `supplier_id` bigint(20) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `asset_id` (`asset_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.asset_maintenances: ~5 rows (approximately)
/*!40000 ALTER TABLE `asset_maintenances` DISABLE KEYS */;
INSERT IGNORE INTO `asset_maintenances` (`id`, `asset_id`, `type_enum`, `title`, `start_date`, `end_date`, `notes`, `supplier_id`, `created_by`, `created_at`, `updated_at`) VALUES
	(1, 1, 'MNT', 'Perbaikan LCD TV', '2021-03-25 00:00:00', '2021-03-26 00:00:00', 'Dead pixel 3', 1, 1, '2021-02-13 06:11:21', '2021-04-25 09:43:28'),
	(2, 1, 'MNT', 'Perbaikan Stand', '2021-03-20 00:02:03', '2021-03-23 17:00:00', 'Perbaikan stand patah', 1, 1, '2021-03-21 00:39:06', '2021-04-25 09:30:14'),
	(3, 2, 'RPR', 'Perbaikan Printer', '2021-03-20 00:02:03', '2021-03-21 23:25:25', 'Perbaikan tinta bocor', 2, 1, '2021-04-18 10:28:07', '2021-04-18 10:28:07'),
	(4, 2, 'MNT', 'Pembersihan head catridge', '2021-04-25 17:00:00', '2021-04-27 17:00:00', 'Melalui software bawaan', 2, 1, '2021-04-24 12:53:26', '2021-04-24 12:53:26'),
	(5, 1, 'RPR', 'Pembersihan paper jam', '2021-04-23 00:00:00', '2021-04-25 00:00:00', 'Ada kertas nyangkut', 2, 1, '2021-04-25 10:12:00', '2021-04-25 10:12:00'),
	(6, 2, 'RPR', 'Perbaikan Tinta Bocor', '2021-04-29 00:00:00', '2021-04-30 00:00:00', 'Tinta warna bocor', 1, 1, '2021-04-29 07:52:18', '2021-04-29 07:52:18');
/*!40000 ALTER TABLE `asset_maintenances` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.contacts
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `contactable_type` varchar(50) DEFAULT NULL,
  `contactable_id` bigint(20) DEFAULT NULL,
  `contact_type` varchar(6) DEFAULT NULL,
  `label` varchar(50) DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contactable_type_contactable_id` (`contactable_type`,`contactable_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.contacts: ~2 rows (approximately)
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT IGNORE INTO `contacts` (`id`, `contactable_type`, `contactable_id`, `contact_type`, `label`, `value`) VALUES
	(1, 'App\\Models\\Jamaah', 1, 'email', 'Pribadi', 'herman.whyd@gmail.com'),
	(2, 'App\\Models\\Jamaah', 1, 'phone', 'Pribadi', '0878123123123'),
	(3, 'App\\Models\\Supplier', 1, 'phone', 'Budi P', '0877123123');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.custom_fields
CREATE TABLE IF NOT EXISTS `custom_fields` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_enum_id` bigint(20) DEFAULT NULL,
  `position` smallint(6) unsigned DEFAULT NULL,
  `field_name` varchar(50) DEFAULT NULL,
  `field_type` varchar(25) DEFAULT NULL,
  `field_reference` varchar(400) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.custom_fields: ~9 rows (approximately)
/*!40000 ALTER TABLE `custom_fields` DISABLE KEYS */;
INSERT IGNORE INTO `custom_fields` (`id`, `group_enum_id`, `position`, `field_name`, `field_type`, `field_reference`) VALUES
	(1, 74, 2, 'Bergaransi', 'dropdown', 'Ya,Tidak'),
	(2, 73, 2, 'Tahun Diperoleh', 'dropdown', '2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025'),
	(3, 73, 1, 'Cara Memperoleh', 'text', NULL),
	(4, 75, 1, 'No STNK', 'text', NULL),
	(5, 74, 1, 'Tgl Garansi Berakhir', 'date', NULL),
	(10, 78, 3, 'Golongan Darah', 'dropdown', 'A,B,AB,O'),
	(11, 78, 1, 'Gelar Depan', 'text', NULL),
	(12, 78, 2, 'Gelar Belakang', 'text', NULL),
	(14, 73, 3, 'PIC Pengguna', 'text', NULL);
/*!40000 ALTER TABLE `custom_fields` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.failed_jobs
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.failed_jobs: ~0 rows (approximately)
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.families
CREATE TABLE IF NOT EXISTS `families` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `kepala_keluarga_id` bigint(20) DEFAULT NULL,
  `label` varchar(100) DEFAULT NULL,
  `residance_id` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.families: ~2 rows (approximately)
/*!40000 ALTER TABLE `families` DISABLE KEYS */;
INSERT IGNORE INTO `families` (`id`, `kepala_keluarga_id`, `label`, `residance_id`, `created_at`, `updated_at`) VALUES
	(1, 1, 'Keluarga Bpk. Herman', 1, '2021-01-31 18:47:28', '2021-01-31 18:47:30'),
	(2, 1, 'Keluarga Bpk. Herman Dummy', 1, '2021-01-31 18:47:28', '2021-01-31 18:47:30');
/*!40000 ALTER TABLE `families` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.family_members
CREATE TABLE IF NOT EXISTS `family_members` (
  `family_id` bigint(20) NOT NULL,
  `jamaah_id` bigint(20) NOT NULL,
  `relationship_enum` varchar(6) NOT NULL,
  `status` varchar(1) NOT NULL,
  `position` tinyint(2) NOT NULL,
  PRIMARY KEY (`family_id`,`jamaah_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.family_members: ~4 rows (approximately)
/*!40000 ALTER TABLE `family_members` DISABLE KEYS */;
INSERT IGNORE INTO `family_members` (`family_id`, `jamaah_id`, `relationship_enum`, `status`, `position`) VALUES
	(1, 1, 'AYH', 'A', 1),
	(1, 2, 'ANK', 'A', 2),
	(1, 3, 'IBU', 'A', 1),
	(1, 4, 'ANK', 'A', 1),
	(2, 1, 'AYH', 'A', 1);
/*!40000 ALTER TABLE `family_members` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.jamaahs
CREATE TABLE IF NOT EXISTS `jamaahs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(150) DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `birth_date` timestamp NULL DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `pembina_enum` varchar(6) DEFAULT NULL,
  `lv_pembinaan_enum` varchar(6) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.jamaahs: ~4 rows (approximately)
/*!40000 ALTER TABLE `jamaahs` DISABLE KEYS */;
INSERT IGNORE INTO `jamaahs` (`id`, `full_name`, `nickname`, `birth_date`, `gender`, `pembina_enum`, `lv_pembinaan_enum`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Herman Wahyudi', 'Herman', '1990-02-06 00:00:00', 'M', 'VJ', 'UBPK', '2021-01-17 06:47:21', '2021-01-17 06:47:22', NULL),
	(2, 'Hiro KZ', 'Hiro', '2020-12-05 00:00:00', 'M', 'VJ', 'PAUD', '2021-01-17 14:41:04', '2021-01-17 14:41:04', NULL),
	(3, 'Pratiwi Anggreini', 'Anggi', '1992-12-10 00:00:00', 'F', 'VJ', 'UIBU', '2021-01-19 19:07:13', '2021-01-19 19:07:13', NULL),
	(4, 'Qeiza Alula Mazaya', 'Qeza', '2017-09-04 00:00:00', 'F', 'VJ', 'CBR', '2021-01-19 19:07:34', '2021-01-19 19:07:35', NULL);
/*!40000 ALTER TABLE `jamaahs` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.jamaah_details
CREATE TABLE IF NOT EXISTS `jamaah_details` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `jamaah_id` bigint(20) DEFAULT NULL,
  `type_enum` varchar(6) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `jamaah_id` (`jamaah_id`),
  KEY `detail_type_enum` (`type_enum`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.jamaah_details: ~2 rows (approximately)
/*!40000 ALTER TABLE `jamaah_details` DISABLE KEYS */;
INSERT IGNORE INTO `jamaah_details` (`id`, `jamaah_id`, `type_enum`, `value`) VALUES
	(1, 1, 'GOLDAR', 'B'),
	(2, 1, 'PFNAME', 'Prof'),
	(3, 1, 'SFNAME', 'S.Kom');
/*!40000 ALTER TABLE `jamaah_details` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.jamaah_pembinaans
CREATE TABLE IF NOT EXISTS `jamaah_pembinaans` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `jamaah_id` bigint(20) NOT NULL,
  `pembina_enum` varchar(6) NOT NULL,
  `lv_pembinaan_enum` varchar(6) NOT NULL,
  `start_date` timestamp NULL DEFAULT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `jamaah_id_pembina_enum_lv_pembinaan_enum` (`jamaah_id`,`pembina_enum`,`lv_pembinaan_enum`),
  KEY `jamaah_id` (`jamaah_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.jamaah_pembinaans: ~2 rows (approximately)
/*!40000 ALTER TABLE `jamaah_pembinaans` DISABLE KEYS */;
INSERT IGNORE INTO `jamaah_pembinaans` (`id`, `jamaah_id`, `pembina_enum`, `lv_pembinaan_enum`, `start_date`, `end_date`) VALUES
	(1, 1, 'VJ', 'RPRP', '2014-01-01 00:00:00', '2016-04-21 00:00:00'),
	(2, 1, 'VJ', 'UBPK', '2021-02-02 07:36:02', NULL);
/*!40000 ALTER TABLE `jamaah_pembinaans` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.locations
CREATE TABLE IF NOT EXISTS `locations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type_enum` varchar(6) DEFAULT NULL,
  `label` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.locations: ~2 rows (approximately)
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT IGNORE INTO `locations` (`id`, `type_enum`, `label`) VALUES
	(1, 'BGNN', 'Manba\'ul \'Ulum'),
	(2, 'BGNN', 'Gria Aslamba'),
	(3, 'BGNN', 'Gria Astaga');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.media
CREATE TABLE IF NOT EXISTS `media` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collection_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disk` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `conversions_disk` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint(20) unsigned NOT NULL,
  `manipulations` json NOT NULL,
  `custom_properties` json NOT NULL,
  `generated_conversions` json NOT NULL,
  `responsive_images` json NOT NULL,
  `order_column` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `media_uuid_unique` (`uuid`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.media: ~25 rows (approximately)
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
INSERT IGNORE INTO `media` (`id`, `model_type`, `model_id`, `uuid`, `collection_name`, `name`, `file_name`, `mime_type`, `disk`, `conversions_disk`, `size`, `manipulations`, `custom_properties`, `generated_conversions`, `responsive_images`, `order_column`, `created_at`, `updated_at`) VALUES
	(3, 'App\\Models\\Asset', 1, '8ea6e2e4-02c7-4fd0-87f0-85d241c174a4', 'INVC', 'Invoice 02.pdf', '1_60319ce1c2bbe.pdf', 'application/pdf', 's3', 'media', 3028, '[]', '{"notes": "Faktur Pajak"}', '[]', '[]', 1, '2021-02-20 23:36:01', '2021-05-02 04:37:36'),
	(4, 'App\\Models\\Asset', 1, '158d22be-f104-4245-a17c-45640133b91a', 'DOCS', 'Invoice 01.pdf', '1_DOCS_60319dfd7be5d.pdf', 'application/pdf', 's3', 'media', 3028, '[]', '{"notes": "Dokumen Invoice dan Faktur."}', '[]', '[]', 2, '2021-02-20 23:40:45', '2021-05-01 20:18:58'),
	(5, 'App\\Models\\Asset', 1, '5aed7d91-f430-4d2b-aad8-9b6b6b7dc8ac', 'PHOTO', 'Avatar.Png', '1_PHOTO_6037cc0a626d1.Png', 'image/png', 's3', 'media', 28329, '[]', '{"notes": "Foto tampak depan closeup"}', '{"THUMB": true}', '[]', 3, '2021-02-25 16:10:50', '2021-05-01 20:17:44'),
	(6, 'App\\Models\\Asset', 1, '2575057b-accc-4687-a346-f76d1eae0094', 'PHOTO', 'Sun Go Ku.Png', '1_PHOTO_6037d043ddf72.Png', 'image/png', 's3', 'media', 18437, '[]', '{"notes": "Foto tampak bahagia close up"}', '{"THUMB": true}', '[]', 4, '2021-02-25 16:28:51', '2021-05-01 20:27:26'),
	(7, 'App\\Models\\Asset', 1, 'd0df684d-33bb-4358-a308-229fb9056c48', 'PHOTO', 'So so Ke.Png', '1_PHOTO_603a6efd8f5a8.Png', 'image/png', 's3', 'media', 45656, '[]', '{"notes": "Foto menantang"}', '{"THUMB": true}', '[]', 5, '2021-02-27 16:10:37', '2021-05-01 20:27:50'),
	(8, 'App\\Models\\Asset', 1, 'e9e82dbe-616c-476d-a11e-cb2bb3a06f26', 'PHOTO', 'One-Piece-anime.Png.Png', '1_PHOTO_6049d4d9bba3c.Png', 'image/png', 's3', 'media', 50405, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 6, '2021-03-11 08:29:13', '2021-03-11 08:29:15'),
	(9, 'App\\Models\\Asset', 1, '68ce3fd1-7255-4077-99fb-9d1d76383363', 'PHOTO', 'Naruto.Png.Png', '1_PHOTO_6049d5853859b.Png', 'image/png', 's3', 'media', 27200, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 7, '2021-03-11 08:32:05', '2021-03-11 08:32:06'),
	(10, 'App\\Models\\Asset', 1, 'e66df27e-66e5-4824-be1a-a8cc03c87032', 'PHOTO', 'Souleater.Png', '1_PHOTO_60533a50868ae.Png', 'image/png', 's3', 'media', 20481, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 8, '2021-03-18 11:32:32', '2021-03-18 11:32:33'),
	(11, 'App\\Models\\Asset', 1, 'b4132997-339a-485c-a77e-17e100ab8437', 'PHOTO', 'Fullmetal-Alchemist.Png', '1_PHOTO_60592eab26206.Png', 'image/png', 's3', 'media', 29127, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 9, '2021-03-23 06:56:27', '2021-03-23 06:56:28'),
	(12, 'App\\Models\\Asset', 1, '30723925-bef3-479d-890d-c8e10d05ef02', 'PHOTO', 'Kuroko-No-Basuke.Png', '1_PHOTO_607a865ad42d7.Png', 'image/png', 's3', 'media', 37383, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 10, '2021-04-17 13:55:22', '2021-04-17 13:55:24'),
	(13, 'App\\Models\\Asset', 1, '8e272ee1-292c-45ff-bab1-03d168e8859a', 'PHOTO', 'Vampire-Knight.Png', '1_PHOTO_607a870f92b08.Png', 'image/png', 's3', 'media', 30637, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 11, '2021-04-17 13:58:23', '2021-04-17 13:58:24'),
	(15, 'App\\Models\\Asset', 2, 'e9636888-7de5-46a1-bfab-418608a58544', 'PHOTO', 'Kuroko-No-Basuke.Png', '2_PHOTO_6083b464be5f2.Png', 'image/png', 's3', 'media', 37383, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 13, '2021-04-24 13:02:12', '2021-04-24 13:02:14'),
	(17, 'App\\Models\\Asset', 1, '45236d02-7cd9-4403-adae-2471cd1dad43', 'PHOTO', 'Hyouka.Png', '1_PHOTO_608c7dd0a956b.Png', 'image/png', 's3', 'media', 35176, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 15, '2021-05-01 04:59:44', '2021-05-01 04:59:46'),
	(18, 'App\\Models\\Asset', 1, 'aa57937b-885c-4755-b371-0810aa2c0549', 'PHOTO', 'Bleach-anime.Png', '1_PHOTO_608dea525e49d.Png', 'image/png', 's3', 'media', 33419, '[]', '{"notes": "Pahlawan bertopeng"}', '{"THUMB": true}', '[]', 16, '2021-05-02 06:54:58', '2021-05-03 02:42:15'),
	(19, 'App\\Models\\Asset', 1, 'a96f8aad-8a9b-40a6-a613-7e5ab16d0b39', 'PHOTO', 'Amnesia-anime.Png', '1_PHOTO_608deb2e0f469.Png', 'image/png', 's3', 'media', 41458, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 17, '2021-05-02 06:58:38', '2021-05-02 06:58:39'),
	(20, 'App\\Models\\Asset', 1, '629fc623-c116-4640-ba84-bd7ce271c088', 'PHOTO', 'Hyouka.Png', '1_PHOTO_608debde1da70.Png', 'image/png', 's3', 'media', 35176, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 18, '2021-05-02 07:01:34', '2021-05-02 07:01:35'),
	(21, 'App\\Models\\Asset', 1, '9509dc1e-876a-441f-849b-f56021f53f22', 'PHOTO', 'Sword-Art-Online.Png', '1_PHOTO_608dec2498829.Png', 'image/png', 's3', 'media', 36003, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 19, '2021-05-02 07:02:44', '2021-05-02 07:02:46'),
	(22, 'App\\Models\\Asset', 1, '05e27635-e696-46fa-8f1b-bd8f5c2c9e38', 'PHOTO', 'Fullmetal-Alchemist.Png', '1_PHOTO_608dedd44ca69.Png', 'image/png', 's3', 'media', 29127, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 20, '2021-05-02 07:09:56', '2021-05-02 07:09:57'),
	(23, 'App\\Models\\Asset', 1, '27d0fa34-9741-476e-98cc-d09033ad25b0', 'PHOTO', 'Vampire-Knight.Png', '1_PHOTO_608dee3e2c83b.Png', 'image/png', 's3', 'media', 30637, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 21, '2021-05-02 07:11:42', '2021-05-02 07:11:43'),
	(24, 'App\\Models\\Asset', 1, '3816c8a6-ef75-45c8-85d1-d62ddccb4748', 'PHOTO', 'One-Piece-anime.Png', '1_PHOTO_608def00b95a9.Png', 'image/png', 's3', 'media', 50405, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 22, '2021-05-02 07:14:56', '2021-05-02 07:14:58'),
	(25, 'App\\Models\\Asset', 1, 'd083be7f-f934-4367-a7b6-23b58085f318', 'PHOTO', 'Fairy-Tail.Png', '1_PHOTO_608df0ce04928.Png', 'image/png', 's3', 'media', 39177, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 23, '2021-05-02 07:22:38', '2021-05-02 07:22:40'),
	(26, 'App\\Models\\Asset', 1, 'b97a70d6-5117-4b51-8801-f311081c9665', 'PHOTO', 'Fullmetal-Alchemist.Png', '1_PHOTO_608df326967e1.Png', 'image/png', 's3', 'media', 29127, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 24, '2021-05-02 07:32:38', '2021-05-02 07:32:40'),
	(27, 'App\\Models\\Asset', 1, '5d57d4fe-0ea2-44c5-b0d1-796c76b5c156', 'PHOTO', 'Bleach-anime.Png', '1_PHOTO_608df33093ef5.Png', 'image/png', 's3', 'media', 33419, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 25, '2021-05-02 07:32:48', '2021-05-02 07:32:50'),
	(30, 'App\\Models\\Asset', 1, 'b2afa86e-969c-4c33-8f24-0d87221302a8', 'PHOTO', 'Amnesia-anime.Png', '1_PHOTO_609fc669cb195.Png', 'image/png', 's3', 'media', 41458, '[]', '{"notes": "Foto manis"}', '{"THUMB": true}', '[]', 28, '2021-05-15 20:02:33', '2021-05-15 20:02:35'),
	(31, 'App\\Models\\Asset', 1, 'd5b32add-d4a8-4a7d-b216-024274147e62', 'PHOTO', 'Dragonball-Goku.Png', '1_PHOTO_609fce1a8a90a.Png', 'image/png', 's3', 'media', 18437, '[]', '{"notes": null}', '{"THUMB": true}', '[]', 29, '2021-05-15 20:35:22', '2021-05-15 20:35:23');
/*!40000 ALTER TABLE `media` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.migrations: ~6 rows (approximately)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT IGNORE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2020_12_16_121441_create_users', 1),
	(3, '2020_12_16_121441_create_media_table', 2),
	(4, '2016_06_27_000000_create_mediable_tables', 3),
	(5, '2020_10_12_000000_add_variants_to_media', 3),
	(6, '2014_10_12_100000_create_password_resets_table', 4),
	(7, '2019_08_19_000000_create_failed_jobs_table', 4),
	(8, '2021_02_15_123105_create_media_table', 4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.m_enums
CREATE TABLE IF NOT EXISTS `m_enums` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `group` varchar(20) NOT NULL,
  `code` varchar(6) DEFAULT NULL,
  `position` mediumint(8) unsigned DEFAULT NULL,
  `label` varchar(400) DEFAULT NULL,
  `removable` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `grup` (`group`,`code`) USING BTREE,
  KEY `posisi` (`position`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.m_enums: ~55 rows (approximately)
/*!40000 ALTER TABLE `m_enums` DISABLE KEYS */;
INSERT IGNORE INTO `m_enums` (`id`, `group`, `code`, `position`, `label`, `removable`) VALUES
	(13, 'IPORTAL_INFO', 'TAGL', 1, 'Hi, informasi apa yang Anda butuhkan?', 0),
	(14, 'IPORTAL_INFO', 'DESC', 2, 'Porta Informasi (IPortal) Jamaah dibangun untuk memudahkan integrasi sistem Jamaah dengan pengurus terkait. Memudahkan proses monitoring keluar-masuk jamaah tiap kelompok, pengolahan bank data, dan lain sebagainya.', 0),
	(15, 'IPORTAL_INFO', 'TELD', 3, 'Telpon Admin untuk support permasalahan yg terjadi di IPortal', 0),
	(16, 'IPORTAL_INFO', 'TELV', 4, '62-8788-4030-354', 0),
	(17, 'IPORTAL_INFO', 'EMLD', 5, 'Email Admin untuk medapatkan informasi lebih lengkap mengenai IPortal', 0),
	(18, 'IPORTAL_INFO', 'IMLV', 6, 'herman.whyd@gmail.com', 0),
	(22, 'RESIDANCE_TYPE', 'SELF', 1, 'Milik Pribadi (Permanent)', 1),
	(23, 'RESIDANCE_TYPE', 'RENT', 2, 'Kontrak/Sewa (Temporal)', 1),
	(25, 'RESIDANCE_TYPE', 'INHR', 3, 'Ikut Orang Tua', 1),
	(26, 'JAMAAH_DETAIL', 'BLDG', 1, 'Golongan Darah', 1),
	(27, 'ASSET_CATEGORY', 'ELCT', 1, 'Barang Elektronik', 1),
	(29, 'ASSET_CATEGORY', 'LAND', 2, 'Tanah', 1),
	(30, 'ASSET_CATEGORY', 'BULD', 3, 'Gedung/Bangunan', 1),
	(31, 'ASSET_CATEGORY', 'FURN', 4, 'Furnitur', 1),
	(33, 'ASSET_CATEGORY', 'KITB', 5, 'Kitab-kitab', 1),
	(34, 'ASSET_STATUS', 'GOOD', 1, 'Baik', 1),
	(35, 'ASSET_STATUS', 'BRKN', 2, 'Rusak', 1),
	(36, 'ASSET_STATUS', 'LOST', 3, 'Hilang', 1),
	(37, 'ASSET_STATUS', 'ARCV', 4, 'Diarsipkan', 1),
	(38, 'FAMS_RELATIONSHIP', 'AYH', 1, 'Ayah', 1),
	(39, 'FAMS_RELATIONSHIP', 'IBU', 2, 'Ibu', 1),
	(41, 'FAMS_RELATIONSHIP', 'ANK', 3, 'Anak', 1),
	(42, 'JAMAAH_DETAIL', 'GOLDAR', 2, 'Golongan Darah', 1),
	(43, 'LV_PEMBINA', 'DS', 1, 'Desa', 1),
	(44, 'LV_PEMBINA', 'KLP', 2, 'Kelompok', 1),
	(45, 'LV_PEMBINAAN', 'UMUM', 1, 'Umum', 1),
	(47, 'LV_PEMBINAAN', 'UBPK', 2, 'Bapak-Bapak', 1),
	(48, 'LV_PEMBINAAN', 'UIBU', 3, 'Ibu-Ibu', 1),
	(49, 'LV_PEMBINAAN', 'RPRP', 4, 'Remaja PRP', 1),
	(50, 'LV_PEMBINAAN', 'RSBY', 5, 'Remaja Sebaya', 1),
	(51, 'LV_PEMBINAAN', 'CBR', 6, 'Caberawit', 1),
	(52, 'LV_PEMBINAAN', 'PAUD', 7, 'Paud', 1),
	(53, 'PEMBINA_DS', 'JPS', 1, 'Japos', 1),
	(54, 'PEMBINA_KLP', 'VJ', 1, 'Villa Japos', 1),
	(55, 'PEMBINA_KLP', 'TMI', 2, 'Taman Mangu Indah', 1),
	(56, 'PEMBINA_KLP', 'PJI', 3, 'Pondok Jati Indah', 1),
	(57, 'PEMBINA_KLP', 'PDA', 4, 'Pondok Aren', 1),
	(58, 'JAMAAH_DETAIL', 'PFNAME', 3, 'Gelar Depan', 1),
	(60, 'JAMAAH_DETAIL', 'SFNAME', 4, 'Gelar Belakang', 1),
	(61, 'LOCATION_TYPE', 'AREA', 1, 'Area', 1),
	(62, 'LOCATION_TYPE', 'BGNN', 2, 'Bangunan', 1),
	(63, 'LOCATION_TYPE', 'RNGA', 3, 'Ruangan', 1),
	(64, 'ASSET_DETAIL', 'ACQY', 1, 'Tahun Diperoleh', 1),
	(65, 'ASSET_DETAIL', 'ACQM', 2, 'Cara Memperoleh', 1),
	(66, 'MAINTENANCE_TYPE', 'RPR', 1, 'Perbaikan', 1),
	(67, 'MAINTENANCE_TYPE', 'MNT', 2, 'Perawatan Rutin', 1),
	(68, 'ASSET_MEDIA_COLL', 'INVC', 1, 'Faktur Pembelian', 1),
	(69, 'ASSET_MEDIA_COLL', 'DOCS', 2, 'Dokumen Pendukung', 1),
	(70, 'ASSET_MEDIA_COLL', 'PHOTO', 3, 'Foto Aset', 1),
	(71, 'ASSET_MEDIA_COLL', 'AUDIT', 4, 'Dokumentasi Audit', 1),
	(72, 'MAINTENANCE_TYPE', 'DST', 3, 'Pemusnahan', 1),
	(73, 'CUSTOM_FIELD_ASSET', 'MISC', 1, 'Informasi Umum', 1),
	(74, 'CUSTOM_FIELD_ASSET', 'WRNT', 3, 'Informasi Garansi', 1),
	(75, 'CUSTOM_FIELD_ASSET', 'LICE', 2, 'Informasi Dokumen Pendukung', 1),
	(78, 'CUSTOM_FIELD_JAMAAH', 'MISC', 1, 'Informasi Umum', 1);
/*!40000 ALTER TABLE `m_enums` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.password_resets: ~0 rows (approximately)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.rbac_model_has_permissions
CREATE TABLE IF NOT EXISTS `rbac_model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `rbac_model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `rbac_permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.rbac_model_has_permissions: ~0 rows (approximately)
/*!40000 ALTER TABLE `rbac_model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbac_model_has_permissions` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.rbac_model_has_roles
CREATE TABLE IF NOT EXISTS `rbac_model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `rbac_model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `rbac_roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.rbac_model_has_roles: ~2 rows (approximately)
/*!40000 ALTER TABLE `rbac_model_has_roles` DISABLE KEYS */;
INSERT IGNORE INTO `rbac_model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
	(1, 'App\\Models\\User', 1),
	(1, 'App\\Models\\User', 2);
/*!40000 ALTER TABLE `rbac_model_has_roles` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.rbac_permissions
CREATE TABLE IF NOT EXISTS `rbac_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.rbac_permissions: ~0 rows (approximately)
/*!40000 ALTER TABLE `rbac_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbac_permissions` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.rbac_roles
CREATE TABLE IF NOT EXISTS `rbac_roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.rbac_roles: ~2 rows (approximately)
/*!40000 ALTER TABLE `rbac_roles` DISABLE KEYS */;
INSERT IGNORE INTO `rbac_roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
	(1, 'ADMIN', 'api', '2020-12-09 23:54:59', '2020-12-09 23:54:59');
/*!40000 ALTER TABLE `rbac_roles` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.rbac_role_has_permissions
CREATE TABLE IF NOT EXISTS `rbac_role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `rbac_role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `rbac_role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `rbac_permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `rbac_role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `rbac_roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.rbac_role_has_permissions: ~0 rows (approximately)
/*!40000 ALTER TABLE `rbac_role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `rbac_role_has_permissions` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.residances
CREATE TABLE IF NOT EXISTS `residances` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `label` varchar(50) NOT NULL,
  `type_enum` varchar(6) NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.residances: ~1 rows (approximately)
/*!40000 ALTER TABLE `residances` DISABLE KEYS */;
INSERT IGNORE INTO `residances` (`id`, `label`, `type_enum`, `created_at`, `updated_at`) VALUES
	(1, 'Alamat Domisili', 'RENT', '2021-01-19 19:08:32', '2021-01-19 19:08:33');
/*!40000 ALTER TABLE `residances` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.suppliers
CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.suppliers: ~0 rows (approximately)
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT IGNORE INTO `suppliers` (`id`, `title`) VALUES
	(1, 'Aslamba Qania'),
	(2, 'ISS');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `jamaah_id` bigint(20) NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `mobile` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table info_jamaah.users: ~2 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT IGNORE INTO `users` (`id`, `jamaah_id`, `email`, `mobile`, `password`, `created_at`, `updated_at`) VALUES
	(1, 1, 'herman.whyd@gmail.com', '087884939354', '$2y$10$LigHc96M88Nvvrd1p3yAFusl3jZb7yU6kdJtCxhc6DgaPyZNLkww6', '2020-12-09 19:10:01', '2020-12-09 19:10:01'),
	(2, 2, 'hirokz@gmail.com', '087812341354', '$2y$10$DbhO08sVLSDTieIFNKrgNe8ODkjlpVi5ALxCaqQPqKLTTbqAB0MWG', '2021-01-17 22:05:56', '2021-01-17 22:05:56');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Dumping structure for table info_jamaah.variables
CREATE TABLE IF NOT EXISTS `variables` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group` varchar(15) DEFAULT NULL,
  `variable_type` varchar(50) DEFAULT NULL,
  `variable_id` bigint(20) DEFAULT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `variable_type_variable_id` (`variable_type`,`variable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table info_jamaah.variables: ~0 rows (approximately)
/*!40000 ALTER TABLE `variables` DISABLE KEYS */;
/*!40000 ALTER TABLE `variables` ENABLE KEYS */;

-- Dumping structure for trigger info_jamaah.auto_pos_custf
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';
DELIMITER //
CREATE TRIGGER `auto_pos_custf` BEFORE INSERT ON `custom_fields` FOR EACH ROW BEGIN
	SET NEW.position = (select COALESCE(max(s.position), 0) + 1 from custom_fields s WHERE s.group_enum_id = NEW.group_enum_id);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

-- Dumping structure for trigger info_jamaah.auto_pos_enum
SET @OLDTMP_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
DELIMITER //
CREATE TRIGGER `info_jamaah`.`auto_pos_enum` BEFORE INSERT ON `m_enums` FOR EACH ROW BEGIN
	SET NEW.position = (select COALESCE(max(s.position), 0) + 1 from m_enums s where s.group = NEW.group);
END//
DELIMITER ;
SET SQL_MODE=@OLDTMP_SQL_MODE;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
